<?php
function up_rest_api_signin_handler($request) {
    $response = ['status' => 1, 'msg' => 'Error']; // failed

    $params = $request->get_json_params();
    
    if(!isset($params['user_login'], $params['password']) ||
        empty($params['user_login']) ||
        empty($params['password'])
    ) {
        $response['msg'] = 'Username oder Passwort fehlt.';
        return $response;
    }

    $email = sanitize_email($params['user_login']);
    $password = sanitize_text_field($params['password']);
    $user = wp_signon(['user_login' => $email, 'user_password' => $password]);

    if(is_wp_error($user)) {
        $response['msg'] = 'WP-Error';
        return $response;
    }

    $response['status'] = 2; // success
    $response['msg'] = 'Success';
    return $response;
}