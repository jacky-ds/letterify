<?php

function up_rest_card_query($args, $request) {
    $order_by = $request->get_param('orderByRating');

    if(isset($order_by)) {
        $args['orderby'] = 'meta_value_num';
        $args['meta_key'] = 'card_rating';
    }

    return $args;
}