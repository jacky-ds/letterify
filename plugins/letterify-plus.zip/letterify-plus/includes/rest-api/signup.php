<?php
function up_rest_api_signup_handler($request) {
    $response = ['status' => 1, 'msg' => 'Error']; // failed

    $params = $request->get_json_params();
    if(!isset($params['email'], $params['username'], $params['password']) ||
        empty($params['email']) ||
        empty($params['username']) ||
        empty($params['password'])
    ) {
        $response['msg'] = 'E-Mail, Username oder Passwort fehlt.';
        return $response;
    }

    // preventing duplicate users
    $email = sanitize_email($params['email']);
    $username = sanitize_text_field($params['username']);
    $password = sanitize_text_field($params['password']);

    if(username_exists($username) || !is_email($email) || email_exists($email)) {
        $response['msg'] = 'Username oder E-Mail existiert bereits.';
        return $response;
    }

    $userId = wp_insert_user([
        'user_login' => $username,
        'user_pass' => $password,
        'user_email' => $email
    ]);

    if(is_wp_error($userId)) {
        $response['msg'] = 'WP-Error';
        return $response;
    }
    
    wp_new_user_notification($userId, null, 'user');
    wp_set_current_user($userId);
    wp_set_auth_cookie($userId);


    $user = get_user_by('id', $userId);
    do_action('wp_login', $user->user_login(), $user);

    $response['status'] = 2; // success
    $response['msg'] = 'Success';
    return $response;
}