<?php


function up_rest_api_add_rating_handler($request) {
    $response = ['status' => 1, 'msg' => 'Error']; // failed

    $params = $request->get_json_params();
    
    if(!isset($params['postID'], $params['rating']) ||
        empty($params['postID']) ||
        empty($params['rating'])
    ) {
        $response['msg'] = 'PostID oder Rating fehlt.';
        return $response;
    }

    $postID = absint($params['postID']);
    $rating = floatval($params['rating']);
    $userID = get_current_user_id();

    global $wpdb;

    // prepare() to clean query from dangerous datat
    $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}card_ratings WHERE post_id={$postID} AND user_id={$userID}"
    ));

    if($wpdb->num_rows > 0) {
        $response['msg'] = 'User has already rated.';
        return $response;
    }

    $wpdb->insert(
        "{$wpdb->prefix}card_ratings",
        ['post_id' => $postID, 'rating' => $rating, 'user_id' => $userID],
        ['%d', '%f', '%d']
    );

    $avgRating = $wpdb->get_var($wpdb->prepare(
        "SELECT AVG(`rating`) FROM {$wpdb->prefix}card_ratings WHERE post_id={$postID}"
    ));

    $avgRating = round($avgRating, 1);

    update_post_meta($postID, 'card_rating', $avgRating);

    do_action('card_rated', [
        'postID' => $postID,
        'rating' => $rating,
        'userID' => $userID
    ]);

    $response['status'] = 2; // success
    $response['msg'] = 'Success';
    $response['rating'] = $avgRating;
    return $response;
}