<?php

function up_activate_plugin() {
    $current_version = get_bloginfo('version');
    $supported_version = '5.9';
    // if currenct_version is smaller than supported_version
    if(version_compare($current_version, $supported_version, '<')) {
        wp_die(__('You must update Wordpress to use this plugin.', 'letterify-plus'));
    }

    up_card_post_type();
    cwpai_create_tshirt_post_type();
    flush_rewrite_rules();

    $options = get_option('up_options');

    if(!$options) {
        add_option('up_options', [
            'og_title' => get_bloginfo('name'),
            'og_img' => '',
            'og_description' => get_bloginfo('description'),
            'enable_og' => 1
        ]);
    }


}