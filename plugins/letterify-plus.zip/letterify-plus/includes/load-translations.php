<?php

// register  translations
function up_load_php_translations() {
    load_plugin_textdomain('letterify-plus', false, 'letterify-plus/languages '); 
}