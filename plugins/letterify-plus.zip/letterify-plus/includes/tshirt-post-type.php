<?php
// Create a custom post type called "tshirt"
function cwpai_create_tshirt_post_type() {
    $labels = array(
        'name'                  => _x( 'T-Shirts', 'Post Type General Name', 'text_domain' ),
        'singular_name'         => _x( 'T-Shirt', 'Post Type Singular Name', 'text_domain' ),
        'menu_name'             => __( 'T-Shirts', 'text_domain' ),
        'name_admin_bar'        => __( 'T-Shirts', 'text_domain' ),
        'archives'              => __( 'T-Shirt Archives', 'text_domain' ),
        'attributes'            => __( 'T-Shirt Attributes', 'text_domain' ),
        'parent_item_colon'     => __( 'Parent T-Shirt:', 'text_domain' ),
        'all_items'             => __( 'All T-Shirts', 'text_domain' ),
        'add_new_item'          => __( 'Add New T-Shirt', 'text_domain' ),
        'add_new'               => __( 'Add New', 'text_domain' ),
        'new_item'              => __( 'New T-Shirt', 'text_domain' ),
        'edit_item'             => __( 'Edit T-Shirt', 'text_domain' ),
        'update_item'           => __( 'Update T-Shirt', 'text_domain' ),
        'view_item'             => __( 'View T-Shirt', 'text_domain' ),
        'view_items'            => __( 'View T-Shirts', 'text_domain' ),
        'search_items'          => __( 'Search T-Shirts', 'text_domain' ),
        'not_found'             => __( 'No T-Shirts found', 'text_domain' ),
        'not_found_in_trash'    => __( 'No T-Shirts found in Trash', 'text_domain' ),
        'featured_image'        => __( 'Featured Image', 'text_domain' ),
        'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
        'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
        'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
        'insert_into_item'      => __( 'Insert into T-Shirt', 'text_domain' ),
        'uploaded_to_this_item' => __( 'Uploaded to this T-Shirt', 'text_domain' ),
        'items_list'            => __( 'T-Shirts list', 'text_domain' ),
        'items_list_navigation' => __( 'T-Shirts list navigation', 'text_domain' ),
        'filter_items_list'     => __( 'Filter T-Shirts list', 'text_domain' ),
    );
    $args = array(
        'label'                 => __( 'T-Shirt', 'text_domain' ),
        'description'           => __( 'T-Shirt Custom Post Type', 'text_domain' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor', 'thumbnail', 'comments', 'revisions', 'custom-fields' ),
        'taxonomies'            => array( 'category', 'post_tag' ),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 21,
        'menu_icon'             => 'dashicons-tshirt',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'tshirt' ),
        'show_in_rest' 		=> true,
    );

    register_post_type( 'tshirt', $args );

    
    register_taxonomy('colors', 'tshirt', [
		'label' => __('Farben', 'letterify-plus'),
		'rewrite' => ['slug' => 'colors'],
		'show_in_rest' => true
	]);

    register_post_meta('tshirt', 'tshirt_rating', [
		'type' => 'number',
		'description' => __('The rating for a t-shirt.', 'letterify-plus'),
		'single' => true,
		'default' => 0,
		'show_in_rest' => true
	]);
}