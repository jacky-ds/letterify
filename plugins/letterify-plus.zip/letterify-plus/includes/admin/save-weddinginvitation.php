<?php

function up_save_weddinginvitation_meta($termID) {
    // check if data is available
    if(!isset($_POST['up_more_info_url'])) {
        return;
    }

    // add_term_meta($termID, 'up_more_info_url', sanitize_url($_POST['up_more_info_url']));
    update_term_meta($termID, 'up_more_info_url', sanitize_url($_POST['up_more_info_url']));

}