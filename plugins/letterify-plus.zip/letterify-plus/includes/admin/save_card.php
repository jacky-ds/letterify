<?php

function up_save_post_card($postID) {
    //check if autosave is active in wordpress
    if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // save manually
    $rating = get_post_meta($postID, 'card_rating', true);

    // first time save: rating will be empty
    $rating = empty($rating) ? 0 : floatval($rating);

    update_post_meta($postID, 'card_rating', $rating);
}