<?php


function up_weddinginvitation_add_form_fields() {
    ?>
    <div class="form-field form-required term-name-wrap">
        <label for="up_more_info_url">
            <?php echo __('Mehr Infos URL', 'letterify-plus'); ?>
        </label>
        <input name="up_more_info_url" id="up_more_info_url" type="text" value="" size="40" aria-required="true" aria-describedby="up_more_info_url-description">
        <p id="up_more_info_url-description">
            <?php echo __('Die URL um mehr Informationen über die Taxonomie zu erhalten.', 'letterify-plus'); ?>
        </p>
    </div>

    <?php
}

function up_weddinginvitation_edit_form_fields($term) {
    $url = get_term_meta($term->id, 'up_more_info_url', true);
    ?>

    <tr class="form-field form-required term-name-wrap">
        <th scope="row">
            <label for="up_more_info_url">
                <?php echo __('Mehr Infos URL', 'letterify-plus'); ?>
            </label>
        </th>
        <td>
            <input name="up_more_info_url" id="up_more_info_url" type="text" value="<?php echo $url; ?>" size="40" aria-required="true" aria-describedby="up_more_info_url-description">
            <p class="description" id="up_more_info_url-description">
                <?php echo __('Die URL um mehr Informationen über die Taxonomie zu erhalten.', 'letterify-plus'); ?>
            </p>
        </td>
    </tr>
    <?php
}