<?php

function up_page_header_cb($atts) {
    $heading = esc_html($atts['content']);
    $showCategory = esc_html($atts['showCategory']);

    if($showCategory) {
        $heading = get_the_archive_title();
    }

    ob_start();

    ?>

    <div class="wp-block-letterify-plus-page-header">
        <div class="inner-page-header">
        
        <h1><?php echo $heading; ?></h1>
        </div>
    </div>

    <?php

    $output = ob_get_contents();
    ob_end_clean();

    return $output;
}