<?php

function up_cards_summary_render_cb($atts, $content, $block) {
    $date = isset($atts['date']) ? esc_html($atts['date']) : '';
    $time = isset($atts['time']) ? esc_html($atts['time']) : '';
    $location = isset($atts['location']) ? esc_html($atts['location']) : '';

    $postID = $block->context['postId'];
    $postTerms = get_the_terms($postID, 'weddinginvitation');
    $postTerms = is_array($postTerms) ? $postTerms : [];

    $wInvitations = '';
    $lastKey = array_key_last($postTerms);
    foreach ($postTerms as $key => $term) {
        $url = get_term_meta($term->term_id, 'up_more_info_url', true);
        $comma = ($key === $lastKey) ? '' : ', ';

        $wInvitations .= "<a href='{$url}' target='_blank' title='$term->name'>{$term->name}</a>{$comma}";
    }

    $rating = get_post_meta($postID, 'card_rating', true);

    global $wpdb;
    $userID = get_current_user_id();

    // check if rating with user_id already exists
    $countRating = $wpdb->get_var($wpdb->prepare(
      "SELECT COUNT(*) FROM {$wpdb->prefix}card_ratings WHERE post_id=%d AND user_id=%d",
      $postID, $userID)
    );

    ob_start();

    ?>

    <div class="wp-block-letterify-plus-cards-summary">
        <i class="bi bi-alarm"></i>
        <div class="card-columns-2">
            <div class="card-metadata">
              <div class="card-title">
                <?php _e('Datum', 'letterify-plus') ?>
              </div>
              <div class="card-data card-date">
                <?php echo $date; ?>
              </div>
            </div>
            <div class="card-metadata">
              <div class="card-title">
                <?php _e('Uhrzeit', 'letterify-plus') ?>
              </div>
              <div class="card-data card-time">
                <?php echo $time; ?>
              </div>
            </div>
        </div>
        <div class="card-columns-2-alt">
            <div class="card-columns-2">
              <div class="card-metadata">
                <div class="card-title">
                    <?php _e('Location', 'letterify-plus') ?>
                </div>
                <div class="card-data card-location">
                    <?php echo $location; ?>
                </div>
              </div>
              <div class="card-metadata">
                <div class="card-title">
                    <?php _e('Hochzeitseinladung für', 'letterify-plus') ?>
                </div>
                <div class="card-data card-weddinginvitations">
                    <?php echo $wInvitations; ?>
                </div>
              </div>
              <i class="bi bi-egg-fried"></i>
            </div>

            <div class="card-metadata">
              <div class="card-title">
                <?php _e('Rating', 'letterify-plus') ?>
              </div>
              <div class="card-data card-rating"
                id="card-rating"
                data-post-id="<?php echo $postID; ?>"
                data-avg-rating="<?php echo $rating; ?>"
                data-logged-in="<?php echo is_user_logged_in(); ?>"
                data-rating-count="<?php echo $countRating; ?>"
              >
              </div>
              <i class="bi bi-hand-thumbs-up"></i>
            </div>
          </div>
        </div>
    </div>

    <?php
    $output = ob_get_contents();
    ob_get_clean();
   
    return $output;
}