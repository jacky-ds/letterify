import "./main.css";

const ogImageBtn = document.querySelector('#og-img-btn');
const ogImageContainer = document.querySelector('#og-img-preview');
const ogImageInput = document.querySelector('#up_og_image');

const mediaFrame = wp.media({
    title: 'Selct or Upload',
    button: {
        text: 'Use me!'
    },
    multiple: false
});

ogImageBtn.addEventListener('click', (ev) => {
    ev.preventDefault();
    mediaFrame.open();
})

mediaFrame.on('select', () => {
    const attachment = mediaFrame.state().get('selection').first().toJSON();
    ogImageContainer.src = attachment.sizes.opengraph.url;
    ogImageInput.value = attachment.sizes.opengraph.url;
})