import { registerBlockType } from '@wordpress/blocks'
import {  useBlockProps, InspectorControls, RichText } from '@wordpress/block-editor'
import { __ } from '@wordpress/i18n'
import { PanelBody, QueryControls } from '@wordpress/components';
import icons from '../../icons/icons';
import { useSelect } from '@wordpress/data';
import { RawHTML } from "@wordpress/element";
import './main.css'

registerBlockType('letterify-plus/popular-tshirts', {
  icon: {
    src: icons.unicorn
  },
	edit({ attributes, setAttributes }) {
    const { title, count, colors } = attributes;
    const blockProps = useBlockProps();

    const terms = useSelect((select) => {
      return select('core').getEntityRecords('taxonomy', 'colors', { per_page: -1 });
    }, [])

    
    const suggestions = {};
    terms?.forEach((term) => {
      suggestions[term.name] = term;
    });

    const colorIDs = colors.map((c) => c.id);
    const posts = useSelect((select) => {
      return select('core').getEntityRecords('postType', 'card', {
        per_page: count,
        _embed: true,
        weddinginvitation: 10,
        order: 'desc',
        orderByRating: 1
      })
    }, [count, colorIDs]);

    console.log(posts);

    return (
      <>
        <InspectorControls>
          <PanelBody title={__('Settings', 'letterify-plus')}>
            <QueryControls
              numberOfItems={count}
              maxItems={10}
              minItems={1}
              onNumberOfItemsChange={ (newVal) => setAttributes( { count: newVal } )}
              categorySuggestions={suggestions}
              onCategoryChange={ ( newVal ) => {
                const newColors = [];

                newVal.forEach((color) => {
                  if(typeof color === 'object') {
                    return newColors.push(color);
                  }

                  const colorTerm = terms?.find((t) => t.name === color );
                  if(colorTerm) {
                    newColors.push(colorTerm);
                  }

                  setAttributes({colors: newColors});
                });

              }}
              selectedCategories={colors}
            />
          </PanelBody>
        </InspectorControls>
        <div {...blockProps}>
          <RichText
            tagName="h6"
            value={ title }
            withoutInteractiveFormatting
            onChange={ title => setAttributes({ title }) }
            placeholder={ __('Überschrift', 'letterify-plus') }
          />
          { posts?.map((post) => {
            const featuredImage = post._embedded && post._embedded['wp:featuredmedia'] && post._embedded['wp:featuredmedia'].length > 0 && post._embedded['wp:featuredmedia'][0];
            return (
              <div className="single-post">
                { featuredImage && (
                  <a className="single-post-image" href={post.link}>
                    <img src={featuredImage.media_details.sizes.thumbnail.source_url} alt={featuredImage.alt_text} />
                  </a>
                )}
                <div className="single-post-detail">
                  <a href={post.link}>
                    <RawHTML>{post.title.rendered}</RawHTML>
                  </a>
                  <span>
                    by <a href={post.link}>{post._embedded.author[0].name}</a>
                  </span>
                </div>
              </div>
            )
          })}
         
        </div>
      </>
    );
  }
});