import { registerBlockType } from '@wordpress/blocks';
import { useBlockProps, InspectorControls } from '@wordpress/block-editor';
import { PanelBody, SelectControl, CheckboxControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import icons from '../../icons/icons';
import './main.css'

registerBlockType('letterify-plus/header-tools', {
  icon: {
    src: icons.unicorn
  },
  edit({ attributes, setAttributes }) {
    const { showAuth } = attributes;
    const blockProps = useBlockProps();

    return (
      <>
        <InspectorControls>
          <PanelBody title={ __('Allgemein', 'letterify-plus') }>
          <SelectControl
            onChange={(newValue) => setAttributes({showAuth: Boolean(newValue)})}
            label={__("Link für Login/Registrierung anzeigen", "letterify-plus")}
            value={showAuth}
            options={[
              {
                label: __("na", "letterify-plus"),
                value: false
              },
              {
                label: __("jo", "letterify-plus"),
                value: true
              },
            ]}
          />

          <CheckboxControl
            checked
            help={showAuth ? __("Link wird angezeigt", "letterify-plus") : __("Link wird NICHT angezeigt.", "letterify-plus")}
            label={__("Link für Login/Registrierung anzeigen", "letterify-plus")}
            onChange={(newValue) => setAttributes({showAuth: newValue})}
          />

          </PanelBody>
        </InspectorControls>
        <div { ...blockProps }>
          { showAuth &&
            <a className="signin-link open-modal" href="#">
              <div className="signin-icon">
                <i className="bi bi-person-circle"></i>
              </div>
              <div className="signin-text">
                <small>Hello, Sign in</small>
                My Account
              </div>
            </a> 
          }
        </div>
      </>
    );
  }
});