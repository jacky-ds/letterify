import Rating from '@mui/material/Rating';
import { render, useState, useEffect } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';

function CardRating({postID, avgRating, loggedIn, ratingCount}) {
    const [avgRatingCard, setAvgRatingCard] = useState(avgRating);
    const [hasPermission, setHasPermission] = useState(loggedIn);

    useEffect(() => {
        if(ratingCount) {
            setHasPermission(false);
        }
    }, []);

    return (
        <Rating
            value={avgRatingCard}
            precision={0.5}
            onChange={async (event, rating) => {
                if(!hasPermission) {
                    if(loggedIn) {
                        return alert('You have already rated this recipe.');
                    }
                    else {
                        return alert('You need to log in.');
                    }
                }

                setHasPermission(false);
                const response = await apiFetch({
                    path: 'up/v1/rate',
                    method: 'POST',
                    data: {
                        postID: postID,
                        rating: rating
                    }
                });

                if(response.status == 2) {
                    // rating was added
                    setAvgRatingCard(response.rating);
                }
            }}
        />
    )
}

document.addEventListener("DOMContentLoaded", () => {
    const block = document.querySelector('#card-rating');
    if(!block) return;
    const postID = parseInt(block.dataset.postId);
    const avgRating = parseFloat(block.dataset.avgRating);
    const loggedIn = !!block.dataset.loggedIn;
    const ratingCount = !!parseInt(block.dataset.ratingCount);

    render(
        <CardRating postID={postID} avgRating={avgRating} loggedIn={loggedIn} ratingCount={ratingCount} />,
        block
    );

})