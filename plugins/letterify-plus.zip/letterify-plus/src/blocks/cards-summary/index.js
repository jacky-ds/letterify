import { registerBlockType } from '@wordpress/blocks';
import { useBlockProps, RichText } from '@wordpress/block-editor';
import { useEntityProp } from '@wordpress/core-data';
import { useSelect } from '@wordpress/data';
import { __ } from '@wordpress/i18n';
import { Spinner } from '@wordpress/components';
import Rating from '@mui/material/Rating';
import icons from '../../icons/icons';
import './main.css';

registerBlockType('letterify-plus/cards-summary', {
  icon: {
    src: icons.unicorn
  },
  edit({ attributes, setAttributes, context }) {
    const { date, time, location } = attributes;
    const blockProps = useBlockProps();
    const { postId } = context;

    const [termIDs] = useEntityProp('postType', 'card', 'weddinginvitation', postId);

    
    const { weddinginvitations, isLoading } = useSelect((select) => {
      const { getEntityRecords, isResolving } = select('core');
      const taxonomyArgs = ['taxonomy', 'weddinginvitation', { include: termIDs} ];

      return {
        weddinginvitations: getEntityRecords(...taxonomyArgs),
        isLoading: isResolving('getEntityRecords', taxonomyArgs)
      }
    }, [termIDs]);

    const { rating } = useSelect((select) => {
      const { getCurrentPostAttribute } = select('core/editor');
      return {
        rating: getCurrentPostAttribute('meta').card_rating
      }
    })

    return (
      <>
        <div {...blockProps}>
          <i className="bi bi-alarm"></i>
          <div className="card-columns-2">
            <div className="card-metadata">
              <div className="card-title">{__('Datum', 'letterify-plus')}</div>
              <div className="card-data card-date">
                <RichText
                  tagName="span"
                  value={ date } 
                  onChange={ date => setAttributes({ date }) }
                  placeholder={ __('Datum', 'letterify-plus') }
                />
              </div>
            </div>
            <div className="card-metadata">
              <div className="card-title">{__('Uhrzeit', 'letterify-plus')}</div>
              <div className="card-data card-time">
                <RichText
                  tagName="span"
                  value={ time } 
                  onChange={ time => setAttributes({ time }) }
                  placeholder={ __('Uhrzeit', 'letterify-plus') }
                />
              </div>
            </div>
          </div>
          <div className="card-columns-2-alt">
            <div className="card-columns-2">
              <div className="card-metadata">
                <div className="card-title">{__('Location', 'letterify-plus')}</div>
                <div className="card-data card-location">
                  <RichText
                    tagName="span"
                    value={ location } 
                    onChange={ location => setAttributes({ location }) }
                    placeholder={ __('Location', 'letterify-plus') }
                  />
                </div>
              </div>
              <div className="card-metadata">
                <div className="card-title">{__('Hochzeitseinladung für', 'letterify-plus')}</div>
                <div className="card-data card-weddinginvitations">
                  { isLoading ? <Spinner /> : (
                    <>
                      { weddinginvitations && weddinginvitations.map((w, index) => {
                        const comma = (index+1) < weddinginvitations.length ? ', ' : '';

                        return (
                          <span className="card-weddinginvitations--item">
                            <a href={w.meta.up_more_info_url} title={`Hochzeit von ${w.name}`}>{w.name}</a>
                            {comma}
                          </span>
                        )
                      }) }
                    </>
                  )}
                </div>
              </div>
              <i className="bi bi-egg-fried"></i>
            </div>
            <div className="card-metadata">
              <div className="card-title">{__('Rating', 'letterify-plus')}</div>
              <div className="card-data card-rating">
                <Rating
                  value={rating}
                  readOnly={true}
                  size="small"
                  getLabelText={(value) => ''}
                />
              </div>
              <i className="bi bi-hand-thumbs-up"></i>
            </div>
          </div>
        </div>
      </>
    );
  }
});