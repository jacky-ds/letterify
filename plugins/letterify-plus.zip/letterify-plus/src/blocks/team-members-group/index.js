import { registerBlockType } from '@wordpress/blocks';
import {  useBlockProps, InspectorControls, InnerBlocks } from '@wordpress/block-editor';
import { PanelBody, RangeControl, SelectControl } from '@wordpress/components'
import { __ } from '@wordpress/i18n';
import icons from '../../icons/icons';
import './main.css';

registerBlockType('letterify-plus/team-members-group', {
  icon: {
    src: icons.unicorn
  },
  edit({ attributes, setAttributes }) {
    const { columns, imageShape } = attributes;
    const blockProps = useBlockProps({className: `cols-${columns}`});
   
    return (
      <>
        <InspectorControls>
          <PanelBody title={__('Settings', 'letterify-plus')}>
            <RangeControl 
              label={__('Spalten', 'letterify-plus')}
              onChange={columns => setAttributes({columns})}
              value={columns}
              min={2}
              max={4}
            />
            <SelectControl 
              label={__('Bildform', 'letterify-plus')}
              value={ imageShape }
              options={[
                  { label: __('Hexagon', 'letterify-plus'), value: 'hexagon' },
                  { label: __('Rabbet', 'letterify-plus'), value: 'rabbet' },
                  { label: __('Pentagon', 'letterify-plus'), value: 'pentagon' },
              ]}
              onChange={imageShape => setAttributes({ imageShape })}
            />
          </PanelBody>
        </InspectorControls>

        <div {...blockProps}>
          <InnerBlocks
            orientation="horizontal"
            allowedBlocks={ ['letterify-plus/team-member'] }
            template={[
              ['letterify-plus/team-member', { name: 'Jacky Atlas', title: 'CEO', bio: 'greates woman alive.'}],
              ['letterify-plus/team-member'],
              ['letterify-plus/team-member']
            ]}
          />
        </div>
      </>
    );
  },
  save({ attributes }) {
    const { columns } = attributes;
    const blockProps = useBlockProps.save();

    return (
      <div {...blockProps}>
        <InnerBlocks.Content />
      </div>
    )
  }
});