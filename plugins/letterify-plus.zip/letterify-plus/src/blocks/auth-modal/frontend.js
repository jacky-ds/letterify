document.addEventListener("DOMContentLoaded", () => {
    const modalEl = document.querySelector('.wp-block-letterify-plus-auth-modal');
    const openModalBtn = document.querySelectorAll('.open-modal');

    const modalCloseEl = document.querySelectorAll('.modal-overlay, .modal-btn-close');

    // open modal
    openModalBtn.forEach(btn => {
        btn.addEventListener("click", (event) => {
            event.preventDefault();
            modalEl.classList.add('modal-show');
        })
    })

    // close modal
    modalCloseEl.forEach(closeEl => {
        closeEl.addEventListener("click", (event) => {
            event.preventDefault();
            modalEl.classList.remove('modal-show');
        })
    })

    function showFormModalStatus(form, activeClass) {
        const modalStatus = form.querySelectorAll('.modal-status');

        modalStatus.forEach(el => {
            el.style.display = "none"; // hide all status displays

            // only show active status
            if(el.classList.contains(activeClass)) {
                el.style.display = "block";
            } 
        });
    }

    // switch active tabs and forms
    const tabs = document.querySelectorAll('.tabs a');
    const modalForms = modalEl.querySelectorAll('form');

    tabs.forEach(t => {
        t.addEventListener("click", event => {
            event.preventDefault();

            const formid = t.dataset.formid;

            tabs.forEach(t => t.classList.remove('active-tab'));
            modalForms.forEach(f => {
                f.style.display = 'none'
                if(f.id === formid) {
                    f.style.display = 'block';
                }
            });

            t.classList.add('active-tab');
        })
    })

    // submit signup form
    const signupForm = document.querySelector('#signup-tab');
    signupForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const signupFieldset = signupForm.querySelector('fieldset');
        signupFieldset.setAttribute('disabled', true);

        showFormModalStatus(signupForm, 'modal-status-info');
        
        const formData = {
            username: signupForm.querySelector('#su-name').value,
            email: signupForm.querySelector('#su-email').value,
            password: signupForm.querySelector('#su-password').value
        }

        const response = await fetch(up_auth_rest.signup, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        })

        const responseJSON = await response.json();

        if(responseJSON.status === 2) {
            // successfully registered
            showFormModalStatus(signupForm, 'modal-status-success');
            location.reload();
        }
        else {
            signupFieldset.removeAttribute('disabled');
            showFormModalStatus(signupForm, 'modal-status-danger');
        }
    })

    const signinForm = document.querySelector('#signin-tab');
    signinForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const signinFieldset = signinForm.querySelector('fieldset');
        signinFieldset.setAttribute('disabled', true);

        showFormModalStatus(signinForm, 'modal-status-info');

        const formData = {
            'user_login': signinForm.querySelector('#si-email').value,
            'password': signinForm.querySelector('#si-password').value
        }

        const response = await fetch(up_auth_rest.signin, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        })

        const responseJSON = await response.json();

        if(responseJSON.status === 2) {
            // successfully registered
            showFormModalStatus(signinForm, 'modal-status-success');
            location.reload();
        }
        else {
            signinFieldset.removeAttribute('disabled');
            showFormModalStatus(signinForm, 'modal-status-danger');
        }
    })

})