import { registerBlockType } from '@wordpress/blocks';
import { useBlockProps, InspectorControls } from '@wordpress/block-editor';
import { PanelBody, ToggleControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import icons from '../../icons/icons';
import './main.css'

registerBlockType('letterify-plus/auth-modal', {
  icon: {
    src: icons.unicorn
  },
  edit({ attributes, setAttributes }) {
    const { showRegister } = attributes;
    const blockProps = useBlockProps();

    return (
      <>
        <InspectorControls>
          <PanelBody title={ __('Allgemein', 'letterify-plus') }>
          <ToggleControl
                label={__("Registrieren anzeigen", "letterify-plus")}
                checked={ showRegister }
                onChange={ (newValue) => setAttributes({ showRegister: newValue}) }
                help={showRegister ? "Registrier-Formular wird angezeigt." : "Registrier-Formular wird versteck."}
            />
          </PanelBody>
        </InspectorControls>
        <div { ...blockProps }>
            {__("Keine Vorschau für diesen Block verfügbar. Bitte auf der Live Seite nachsehen.", "letterify-plus")}
        </div>
      </>
    );
  }
});