import { registerBlockType } from '@wordpress/blocks';
import edit from './edit';
import save from './save';
import icons from '../../icons/icons';
import './main.css';

registerBlockType('letterify-plus/team-member', {
  icon: {
    src: icons.unicorn
  },
  edit,
  save
});