import { isBlobURL, revokeBlobURL } from '@wordpress/blob';
import { InspectorControls, MediaPlaceholder, MediaReplaceFlow, BlockControls, RichText, useBlockProps } from '@wordpress/block-editor';
import { PanelBody, Spinner, TextareaControl, ToolbarButton, Tooltip, TextControl, Button } from '@wordpress/components';
import { useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';

export default function({ attributes, setAttributes, context }) {
    const {  name, title, bio, imgAlt, imgID, imgURL, socialHandles } = attributes;
    const blockProps = useBlockProps();

    const [ imgPreview, setImgPreview] = useState(imgURL);

    const selectImg = (img) => {
      if(!img) return;

      let newImgUrl = null;
      if(isBlobURL(img.url)) {
        newImgUrl = img.url;
      }
      else {
        newImgUrl = img.sizes ? img.sizes.teamMember.url : img.media_details.sizes.teamMember.source_url;
        setAttributes({imgID: img.id, imgAlt: img.alt, imgURL: newImgUrl });
        revokeBlobURL(imgPreview);
      }

      setImgPreview(newImgUrl);
    }

    const selectImgURL = (url) => {
      setImgPreview(url);
      setAttributes({imgID: null, imgAlt: null, imgURL: url });
    }

    const imageShape = context["letterify-plus/image-shape"];
    const imageClass = `wp-image-${imgID} img-${imageShape}`;

    const [activeSocialLinkIndex, setActiveSocialLinkIndex] = useState(null);

    setAttributes({imageShape: imageShape});

    return (
      <>
        {imgPreview && (
          <BlockControls group="inline">
            <MediaReplaceFlow
              name={__("Bild ersetzen", "letterify-plus")}
              mediaId={imgID}
              mediaURL={imgURL}
              allowedTypes={["image"]}
              accept={"image/*"}
              onError={(error) => console.error(error)}
              onSelect={selectImg}
              onSelectURL={selectImgURL}
            />
            <ToolbarButton onClick={() => selectImgURL('')}>
              {__("Bild entfernen", "letterify-plus")}
            </ToolbarButton>
          </BlockControls>
        )}

        <InspectorControls>
          { (imgPreview && !isBlobURL(imgPreview)) && (
            <PanelBody title={__('Einstellungen', 'letterify-plus')}>
              <TextareaControl 
                label={__('Alt', 'letterify-plus')}
                value={imgAlt}
                onChange={imgAlt => setAttributes({imgAlt})}
                help={__('Bildbeschreibung für Screen-Reader', 'letterify-plus')}
              />
            </PanelBody>
          )}
        </InspectorControls>
        <div {...blockProps}>
          <div className="author-meta">
            { imgPreview && (
              <img src={imgPreview} alt={imgAlt} className={imageClass} /> 
            )}

            { isBlobURL(imgPreview) && (
              <Spinner />
            )}

            <MediaPlaceholder
              allowedTypes={['image']}
              accept={'image/*'}
              icon="admin-users"
              onSelect={selectImg}
              onError={(err) => console.error("ERR:", err) }
              disableMediaButtons={imgPreview}
              onSelectURL={selectImgURL}
            />
            <p>
              <RichText 
                placeholder={__('Name', 'letterify-plus')}
                tagName="strong"
                onChange={name => setAttributes({name})}
                value={name}
              />
              <RichText 
                placeholder={__('Titel', 'letterify-plus')}
                tagName="span"
                onChange={title => setAttributes({title})}
                value={title}
              />
            </p>
          </div>
          <div className="member-bio">
            <RichText 
              placeholder={__('Bio', 'letterify-plus')}
              tagName="p"
              onChange={bio => setAttributes({bio})}
              value={bio}
            />
          </div>
          <div className="social-links">

            { socialHandles.map((handle, index) => {
              return <a href={handle.url} key={index} className={activeSocialLinkIndex === index ? 'is-active' : ''} onClick={(event) => {
                event.preventDefault();
                if(activeSocialLinkIndex !== index) {
                  setActiveSocialLinkIndex(index);
                }
                else {
                  setActiveSocialLinkIndex(null);
                }
              }}>
                <i className={`bi bi-${handle.icon}`}></i>
              </a>
            })}

            <Tooltip text={__('Social Media Handle hinzufügen', 'letteriy-plus')}>
              <a href="#" onClick={(event) => {
                event.preventDefault();
                const questionIcon = { icon: "question", url: "" };
                setAttributes({socialHandles: [...socialHandles, questionIcon]})

                const lastItemIndex = socialHandles.length;
                setActiveSocialLinkIndex(lastItemIndex);
              }}>
                +
              </a>

            </Tooltip>
          </div>

          { activeSocialLinkIndex !== null && (
            <div className='team-member-social-edit-ctr'>
              <TextControl
                label={__('URL', 'letterify-plus')}
                value={socialHandles[activeSocialLinkIndex].url}
                onChange={(url) => {
                  const tempObj = {...socialHandles[activeSocialLinkIndex]};
                  const tempSocial = [...socialHandles]
                  tempObj.url = url;
                  tempSocial[activeSocialLinkIndex] = tempObj;

                  setAttributes({socialHandles: tempSocial });
                }}
              />
              <TextControl
                label={__('IOCN', 'letterify-plus')}
                value={socialHandles[activeSocialLinkIndex].icon}
                onChange={(icon) => {
                  const tempObj = {...socialHandles[activeSocialLinkIndex]};
                  const tempSocial = [...socialHandles]
                  tempObj.icon = icon;
                  tempSocial[activeSocialLinkIndex] = tempObj;

                  setAttributes({socialHandles: tempSocial });
                }}
              />
              <Button isDestructive onClick={() => {
                const tempCopy = [...socialHandles];
                tempCopy.splice(activeSocialLinkIndex, 1);

                setAttributes({socialHandles: tempCopy});
                setActiveSocialLinkIndex(null);
              }}>
                {__('Entfernen', 'letteriy-plus')}
              </Button>
            </div>
          )}
        </div>
      </>
    );
}