import { registerBlockType } from '@wordpress/blocks';
import { RichText, useBlockProps, InspectorControls } from '@wordpress/block-editor';
import { PanelBody, ToggleControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import icons from '../../icons/icons';
import './main.css'

registerBlockType('letterify-plus/page-header', {
  icon: icons.unicorn,
	edit({attributes, setAttributes}) {
    const { content, showCategory } = attributes
    const blockProps = useBlockProps();

    return (
      <>
        <InspectorControls>
          <PanelBody title={__("Allgemein", "letterify-plus")}>
            <ToggleControl
              label={__("Kategorie anzeigen?", "letterify-plus")}
              checked={ showCategory }
              onChange={(newValue) => setAttributes({showCategory: newValue})}
              help={showCategory ? __("Aktuelle Kategorie wird angezeigt", "letterify-plus") : __("Custom Text wird angezeigt", "letterify-plus")}
            />
            </PanelBody>
        </InspectorControls>

        <div {...blockProps}>
          <div className="inner-page-header">
          { showCategory ? 
            <h1>{__("Aktuelle Kategorie [placeholder]", "letterify-plus")}</h1> : 
            <RichText 
              tagName="h1"
              placeholder={__("Überschrift", "letterify-plus")}
              value={content}
              onChange={(newValue) => setAttributes({content: newValue})}
            />
          }
          </div>
        </div>
      </>
    );
  }
});