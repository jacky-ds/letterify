import "./neon.css";
import { registerFormatType, toggleFormat } from '@wordpress/rich-text';
import { RichTextToolbarButton } from '@wordpress/block-editor';
import { __ } from '@wordpress/i18n';
import { useSelect } from '@wordpress/data';

registerFormatType('letterify-plus/neon', {
    title: __('Neon', 'letterify-plus'),
    tagName: 'span',
    className: 'neon',
    edit({ isActive, onChange, value }) {
        const selectedBlock = useSelectb(select => select('core/block-editor').getSelectedBlock());


        return (
            <>
                { selectedBlock?.name === 'core/paragraph' && (

                    <RichTextToolbarButton
                        title={__('Neon', 'letterify-plus')}
                        icon="superhero"
                        isActive={isActive}
                        onClick={() => {
                            onChange(toggleFormat(value, { type: 'letterify-plus/neon' }));
                        }}
                    /> 
                )}
            </>
        )
    }
})

  